import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        char[] board = { '1','2','3',
                         '4','5','6',
                         '7','8','9'  };

        var noOfSquaresPlayed = 0;
        var whoTurn = 'x';
        var endMessage = "GG`s";

        while (noOfSquaresPlayed < 9)
        {
            printTheBoard(board);
            System.out.printf("PLAY! %s:", whoTurn);

            Scanner scanner = new Scanner(System.in);
            var input = scanner.nextInt();

            board[input-1] = whoTurn;

            if ((board[0] + board[1] + board[2]) == (whoTurn * 3)
                ||(board[3] + board[4] + board[5]) == (whoTurn * 3)
                ||(board[6] + board[7] + board[8]) == (whoTurn * 3)
                ||(board[0] + board[3] + board[6]) == (whoTurn * 3)
                ||(board[1] + board[4] + board[7]) == (whoTurn * 3)
                ||(board[2] + board[5] + board[8]) == (whoTurn * 3)
                ||(board[0] + board[4] + board[8]) == (whoTurn * 3)
                ||(board[2] + board[4] + board[6]) == (whoTurn * 3)
                ) {
                printTheBoard(board);
                endMessage = "Nice Win!";
                break;
            } else {
                noOfSquaresPlayed++;
                if (whoTurn == 'x') {
                    whoTurn = 'o';
                } else {
                    whoTurn = 'x';
                }
            }
        }
        System.out.println(endMessage);


    }

    private static void printTheBoard(char[] board)
    {
        System.out.println( board[0] + " | " +  board[1] + " | " + board[2]);
        System.out.println( "- + - + - " );
        System.out.println( board[3] + " | " +  board[4] + " | " + board[5]);
        System.out.println( "- + - + - " );
        System.out.println( board[6] + " | " +  board[7] + " | " + board[8]);
    }
}

